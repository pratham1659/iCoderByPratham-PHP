<?php
require './includes/common.php';
// check if logged in
if ( !isset( $_SESSION["email_id"] ) ) {
    header( "location: login.php" );
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>My Cart</title>
    <!-- link to Bootstrap minified css-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- link to Jquery minified-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- link to Bootstrap JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous">
    </script>
    <!-- link to fontawesome CSS-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- link to external CSS -->
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
require './includes/header.php';

// get the products purchased by the user
$user_id = $_SESSION["id"];
$query = "SELECT p.id, p.name, p.price FROM items p INNER JOIN users_items up ON up.item_id = p.id WHERE up.user_id = '$user_id' AND up.status = 'Added to cart'";

$result = mysqli_query( $con, $query ) or die( mysqli_error( $con ) );

if ( mysqli_num_rows( $result ) == 0 ) {
    echo '<h4 class="container panel-margin">Add products to cart first. Goto <a href="products.php">Products</a> page.</h4>';
} else {
    $total = 0;?>
    <div class="container panel-margin">
        <table class="table table-hover">
            <tr>
                <th>Item Number</th>
                <th>Item Name</th>
                <th>Price</th>
                <th></th>
            </tr>
            <?php while ( $row = mysqli_fetch_array( $result ) ) {?>
            <tr>
                <td><?php echo $row["id"] ?></td>
                <td><?php echo $row["name"] ?></td>
                <td><?php $total += $row["price"];
        echo $row["price"]?></td>
                <td><a href="cart-remove.php?id=<?php echo $row["id"]; ?>">Remove</a></td>
            </tr>
            <?php
}
}
?>
            <tr>
                <td></td>
                <td></td>
                <td>Total: <i class="fa fa-rupee"></i> <?php echo $total; ?></td>
                <td><a href="success.php" class="btn btn-primary">Confirm Order</a></td>
            </tr>
        </table>
    </div>
    <!-- exceptional footer for login page -->
    <div class="footer-login">
        <?php
require './includes/footer.php';
?>
    </div>
</body>

</html>

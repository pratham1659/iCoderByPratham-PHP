<footer class="footer">
    <div class="container fixed-bottom">
        Copyright <span class="glyphicon glyphicon-copyright-mark"></span> LifeStyle Stores.
        All Rights Reserved | Contact Us: +91 90000 00000
    </div>
</footer>
